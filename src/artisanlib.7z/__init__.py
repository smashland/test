__version__ = '2.10.4'
__revision__ = ''
__build__ = '0'

__release_sponsor_name__ = 'Paolo Scimone Coffee Consulting'
__release_sponsor_domain__ = 'paoloscimone.com'
__release_sponsor_url__ = 'https://www.paoloscimone.com/'
